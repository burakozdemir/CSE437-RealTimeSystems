#pragma once

#include "task.h"
#include <thread>
#include "ISimulator.h"
#include "OperatorConsole.h"

class TemperatureController : public Task
{
public:
	TemperatureController(ISimulator& iSimulator, OperatorConsole &opConsole);
	~TemperatureController();

	void setTemperature(double val);
	double getTemperature();

	void start();

	using HRC = std::chrono::high_resolution_clock;
	int tempFreq = 333;
private:
	ISimulator &iSimulator;
	OperatorConsole &opConsole;

	const double C = 3;
	const double D = 10;
	double temperature;

	thread *task;
	void tempThreadFunction();
};

