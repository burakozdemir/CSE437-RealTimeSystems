#pragma once
#include "ISimulator.h"
#include <stdio.h>

class MySimulator : public ISimulator{
public:
	MySimulator();
	~MySimulator();

	void triggerADCPressure();
	void triggerADCTemperature();
	double readADCPressure();
	double readADCTemperature();
	void writeDACPump(const double value);
	void switchHeater(bool isOn);

private:
	double temperature = 7;//start initial value for temperature
	double pressure = 4;//start initial value for pressure
};

