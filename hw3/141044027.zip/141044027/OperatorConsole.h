#pragma once

#include "task.h"
#include <thread>
#include <chrono>
#include <atomic>
#include <mutex>
#include <condition_variable>

using namespace std;
class OperatorConsole : public Task
{
public:
	OperatorConsole();
	~OperatorConsole();

	void start();//start task
	/*
		Setter for pressure and temperature
	*/
	void setPress(double val);
	void setTemp(double val);

	using HRC = std::chrono::high_resolution_clock;//time
	int consoleFreq = 500;//frequency

	HRC::time_point tempUTime;//updated temperature time
	std::mutex tempMutex;//temperature mutex
	condition_variable tempCond;//temperature Condition variable

	HRC::time_point presUTime;//updated pressure time	
	std::mutex pressMutex;//Pressure mutex
	condition_variable pressCond;////Pressure Condition variable


private:
	atomic<double> press;
	atomic<double> temp;
	int frequency;

	thread *task;
	void threadFunction();
};

