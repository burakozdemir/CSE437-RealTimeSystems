#include "stdafx.h"
#include "PressureController.h"
#include <iostream>

using namespace std;

PressureController::PressureController(ISimulator& simulator, OperatorConsole &opConsole):pressure(0),
opConsole(opConsole),iSimulator(simulator){
}


PressureController::~PressureController()
{
	this->task->join();
	delete task;
}

void PressureController::start()
{
	this->task = new thread(&PressureController::pressThreadFunction,this);
}

void PressureController::setPressure(double val)
{
	this->pressure = val;
}

double PressureController::getPressure()
{
	return this->pressure;
}

void PressureController::pressThreadFunction()
{
	HRC::time_point t0, t1;
	double u;
	std::unique_lock<std::mutex> lock(this->opConsole.pressMutex, std::defer_lock);

	while (true) {
		t0 = HRC::now();
		
		lock.lock();
		
		//std::cout << "pressin" << std::endl;
		this->iSimulator.triggerADCPressure();
		this->pressure = this->iSimulator.readADCPressure();
		this->opConsole.setPress(this->pressure);
		//std::cout << "pressout" << std::endl;
		
		lock.unlock();
		
		this->opConsole.pressCond.notify_one();
		
		//Processing
		if (this->pressure < 0.9)
			u = this->A - this->B*this->pressure;
		else
			u = 0;
		iSimulator.writeDACPump(u);
		
		t1 = HRC::now();
		int elapsedTime = chrono::duration_cast<chrono::milliseconds>(t1 - t0).count();
		this_thread::sleep_for(chrono::milliseconds(this->pressFreq - elapsedTime));
	}
}
