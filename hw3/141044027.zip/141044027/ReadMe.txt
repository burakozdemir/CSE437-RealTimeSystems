========================================================================
    CONSOLE APPLICATION : Plant_System HW3 (Burak Özdemir 141044027)
========================================================================

1.Test için kendi Simulator sýnýfýnýzý ÝSimulator arayüzünden implement edin.
2.PressureConroller frekansý 10 Hz, TemperatureController frekansý 3 Hz ,
OperatorConsole frekansý 2 Hz
3.Task'lar initialize edildikten sonra start() metodu ile baþlatýlýr .
4.Pressure ve Temperature min max deðerleri header dosyalarýndan manuel olarak
deðiþtirilebilir.
5.RR policy değişkeni seçildi , RT yapılamadı .
6.Controller taskları priority değerleri 10 olarak verildi.
7.Temperature ve Pressure değerleri 2 ayri mutex ile korunuyor .
8.OperatorConsole sinifinda deadline miss durumu 10 millisaniye de bir kontrol
ediliyor . Deadline miss olursa ekrana warning mesaji basilacak .

/////////////////////////////////////////////////////////////////////////////
Results :
	-Test durumunda readADC fonksiyonunda random deðerler ürettirip max ve min 
aralýklarýnda gidip gelmesi saðlandý . 
	-Pressure initialize deðerinden baþlayýp sürekli '1' civarlarýnda gidip geldi
	-Temperature deðeri ise max ve min aralýklarýn düzenli þekilde artan ve azalan
deðerler gösterdi .
	-trigger fonksiyonlarına sleep koyulunca deadline miss değerleri görüldü .
/////////////////////////////////////////////////////////////////////////////

HOW WORK :
	1. "make" komutunu çalıştırın
	2. "sudo ./run" ile programı çalıştırın
