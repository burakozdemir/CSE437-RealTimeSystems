#include "stdafx.h"
#include "OperatorConsole.h"
#include <iostream>
#include <iomanip>

OperatorConsole::OperatorConsole() :frequency(consoleFreq)
{
}


OperatorConsole::~OperatorConsole()
{
	this->task->join();
	delete this->task;
}

void OperatorConsole::start()
{
	this->task = new thread(&OperatorConsole::threadFunction, this);
}

void OperatorConsole::setPress(double val)
{
	this->press = val;
}

void OperatorConsole::setTemp(double val)
{
	this->temp = val;
}

void OperatorConsole::threadFunction()
{
	int passedTime;
	HRC::time_point t0, t1, t3;
	std::unique_lock<std::mutex> tempLock(this->tempMutex, std::defer_lock);
	std::unique_lock<std::mutex> presLock(this->pressMutex, std::defer_lock);

	double tempTemperature = 0, tempPressure = 0;

	while (true) {
		t0 = HRC::now();
		
		tempLock.lock();
		tempCond.wait(tempLock);

		presLock.lock();
		pressCond.wait(presLock);
		
		/*
			�nceki de�er kontrol�
		*/
		if (this->temp != tempTemperature && this->press != tempPressure) {
			//std::cout << "consolein" << std::endl;
			cout << "Temperature:" << this->temp << ", Pressure:" << this->press << std::endl;
			//std::cout << "consoleout" << std::endl;
		}
		tempTemperature = this->temp;
		tempPressure = this->press;
		
		tempLock.unlock();
		presLock.unlock();

		t1 = HRC::now();
		//Frekans'� tutturmak i�in gerekli s�re
		passedTime = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
		std::this_thread::sleep_for(std::chrono::milliseconds(this->frequency - passedTime));

	}
}
