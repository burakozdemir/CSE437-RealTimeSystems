#pragma once

#include "task.h"
#include <thread>
#include <chrono>
#include <atomic>
#include <mutex>

using namespace std;
class OperatorConsole : public Task
{
public:
	OperatorConsole();
	~OperatorConsole();

	void start();//start task
	/*
		Setter for pressure and temperature
	*/
	void setPress(double val);
	void setTemp(double val);

	using HRC = std::chrono::high_resolution_clock;//time
	int consoleFreq = 500;//frequency

	std::mutex tempMutex;//temperature mutex
	std::condition_variable tempCond;//temperature Condition variable
	
	std::mutex pressMutex;//Pressure mutex
	std::condition_variable pressCond;////Pressure Condition variable


private:
	atomic<double> press;
	atomic<double> temp;
	int frequency;

	thread *task;
	void threadFunction();
};

