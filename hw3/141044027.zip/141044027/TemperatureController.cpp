#include "TemperatureController.h"
#include <chrono>
#include <iostream>

TemperatureController::TemperatureController(ISimulator& iSimulator, OperatorConsole &opConsole):iSimulator(iSimulator),
opConsole(opConsole),temperature(0){
}

TemperatureController::~TemperatureController()
{
	this->task->join();
	delete this->task;
}

void TemperatureController::setTemperature(double val)
{
	this->temperature = val;
}

double TemperatureController::getTemperature()
{
	return this->temperature;
}

void TemperatureController::start()
{
    sched_param scheduler;
	this->task = new thread(&TemperatureController::tempThreadFunction, this);
    scheduler.sched_priority=10;
    auto threadF = this->task->native_handle();
    if(pthread_setschedparam(threadF,SCHED_RR,&scheduler)){
		cerr<<"Thread scheduling error"<<endl;
	}   
}

void TemperatureController::tempThreadFunction()
{
	HRC::time_point t0, t1;
	bool status = false;
	std::unique_lock<std::mutex> lock(this->opConsole.tempMutex,std::defer_lock);

	while (true) {
		t0 = HRC::now();

        this->iSimulator.triggerADCTemperature();
		this->temperature = this->iSimulator.readADCTemperature();
		
		lock.lock();
		this->opConsole.setTemp(this->temperature);
		lock.unlock();
        
		
		//Processing
		if (D < this->temperature) {
			status = false;
		}
		else if (C > this->temperature) {
			status = true;
		}
		
		this->iSimulator.switchHeater(status);
		
		t1 = HRC::now();
		int elapsedTime = chrono::duration_cast<chrono::milliseconds>(t1 - t0).count();
		this_thread::sleep_for(chrono::milliseconds(this->tempFreq - elapsedTime));
	}
}

