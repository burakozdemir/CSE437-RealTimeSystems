#include "PressureController.h"
#include <iostream>

using namespace std;

PressureController::PressureController(ISimulator& simulator, OperatorConsole &opConsole):pressure(0),
opConsole(opConsole),iSimulator(simulator){
}


PressureController::~PressureController()
{
	this->task->join();
	delete task;
}

void PressureController::start()
{
    sched_param scheduler;
	this->task = new thread(&PressureController::pressThreadFunction,this);
    scheduler.sched_priority=10;
    auto threadF = this->task->native_handle();
    if(pthread_setschedparam(threadF,SCHED_RR,&scheduler)){
		cerr<<"Thread scheduling error"<<endl;
	}
}

void PressureController::setPressure(double val)
{
	this->pressure = val;
}

double PressureController::getPressure()
{
	return this->pressure;
}

void PressureController::pressThreadFunction()
{
	HRC::time_point t0, t1;
	double u;
	std::unique_lock<std::mutex> lock(this->opConsole.pressMutex, std::defer_lock);

	while (true) {
		t0 = HRC::now();
		
		this->iSimulator.triggerADCPressure();
		this->pressure = this->iSimulator.readADCPressure();
		
		lock.lock();
		this->opConsole.setPress(this->pressure);
		lock.unlock();
        
		//Processing
		if (this->pressure < 0.9)
			u = this->A - this->B*this->pressure;
		else
			u = 0;
		iSimulator.writeDACPump(u);
		
		t1 = HRC::now();
		int elapsedTime = chrono::duration_cast<chrono::milliseconds>(t1 - t0).count();
		this_thread::sleep_for(chrono::milliseconds(this->pressFreq - elapsedTime));
	}
}
