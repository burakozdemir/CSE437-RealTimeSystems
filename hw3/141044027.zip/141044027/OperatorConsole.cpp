#include "OperatorConsole.h"
#include <iostream>
#include <iomanip>

OperatorConsole::OperatorConsole() :frequency(consoleFreq)
{
}


OperatorConsole::~OperatorConsole()
{
	this->task->join();
	delete this->task;
}

void OperatorConsole::start()
{
	this->task = new thread(&OperatorConsole::threadFunction, this);
}

void OperatorConsole::setPress(double val)
{
	this->presUTime=HRC::now();
	this->press = val;
}

void OperatorConsole::setTemp(double val)
{
	this->tempUTime=HRC::now();
	this->temp = val;
}

void OperatorConsole::threadFunction()
{
	int passedTime,pressMissTime,tempMissTime;
	HRC::time_point t0, t1, missTime;
	std::unique_lock<std::mutex> tempLock(this->tempMutex, std::defer_lock);
	std::unique_lock<std::mutex> presLock(this->pressMutex, std::defer_lock);
	this->tempUTime=HRC::now();
	this->presUTime=HRC::now();
	double tempTemperature = 0, tempPressure = 0;
	bool preFlag=false;
	bool tempFlag=false;

	while (true) {
		t0 = HRC::now();

		//flags reset
		preFlag=true;
		tempFlag=true;

		//temperature değerini güvenli alma
		tempLock.lock();
		tempTemperature = this->temp;
		tempLock.unlock();
		
		//pressure değerini güvenli alma
		presLock.lock();
		tempPressure = this->press;
		presLock.unlock();

		/*
			10 milli saniyede bir miss deadline kontrolü
		*/
		for(int k=0;k<49;k++){
			missTime=HRC::now();

			//pressure deadline miss time
			pressMissTime=std::chrono::duration_cast<std::chrono::milliseconds>(missTime - this->presUTime).count();
			pressMissTime-=100;//10 HZ 
			
			//temperature deadline miss time
			tempMissTime=std::chrono::duration_cast<std::chrono::milliseconds>(missTime - this->tempUTime).count();
			tempMissTime-=333;//3 HZ
			
			if(pressMissTime>0 && preFlag){
				cout << "WARNING! PressureController deadline miss by " << pressMissTime << " milliseconds." <<endl;
				cout.flush();
				preFlag=false;
			}

			if(tempMissTime>0 && tempFlag){
				cout << "WARNING! TemperatureController deadline miss by " << tempMissTime << " milliseconds." <<endl;
				cout.flush();
				tempFlag=false;	
			}
			
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
		}


		cout << "Temperature:" << this->temp << ", Pressure:" << this->press << std::endl;
        cout.flush();
				
       
		t1 = HRC::now();
		//Frekans'ý tutturmak için gerekli süre
		passedTime = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
		std::this_thread::sleep_for(std::chrono::milliseconds(this->frequency - passedTime));

	}
}
