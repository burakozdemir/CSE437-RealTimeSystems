#pragma once

class Task {
public:
	virtual void start() = 0;
};