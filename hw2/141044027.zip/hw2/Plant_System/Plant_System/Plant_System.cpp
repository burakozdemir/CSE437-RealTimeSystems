// Plant_System.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <thread>
#include "PressureController.h"
#include "TemperatureController.h"
#include "OperatorConsole.h"
#include "ISimulator.h"
#include "MySimulator.h"
using namespace std;

int main(int argc, char *argv[])
{
	ISimulator *mySimulator = new MySimulator();

	OperatorConsole * operatorConsole = new OperatorConsole();//2 Hz
	operatorConsole->start();//Console Thread Start

	PressureController *pressController = new PressureController(*mySimulator, *operatorConsole);// 10Hz
	pressController->start();//Pressure Thread Start
	
	TemperatureController *temperatureController = new TemperatureController(*mySimulator, *operatorConsole);//3 Hz
	temperatureController->start();//Temperature Thread Start
	
	while(true);
    return 0;
}

