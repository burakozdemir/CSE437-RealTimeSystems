#include "stdafx.h"
#include "TemperatureController.h"
#include <chrono>
#include <iostream>

TemperatureController::TemperatureController(ISimulator& iSimulator, OperatorConsole &opConsole):iSimulator(iSimulator),
opConsole(opConsole),temperature(0){
}

TemperatureController::~TemperatureController()
{
	this->task->join();
	delete this->task;
}

void TemperatureController::setTemperature(double val)
{
	this->temperature = val;
}

double TemperatureController::getTemperature()
{
	return this->temperature;
}

void TemperatureController::start()
{
	this->task = new thread(&TemperatureController::tempThreadFunction, this);
}

void TemperatureController::tempThreadFunction()
{
	HRC::time_point t0, t1;
	bool status = false;
	std::unique_lock<std::mutex> lock(this->opConsole.tempMutex,std::defer_lock);

	while (true) {
		t0 = HRC::now();

		lock.lock();
		
		//std::cout << "tempin" << std::endl;
		this->iSimulator.triggerADCTemperature();
		this->temperature = this->iSimulator.readADCTemperature();
		this->opConsole.setTemp(this->temperature);
		//std::cout << "tempOut" << std::endl;
		
		lock.unlock();
		
		this->opConsole.tempCond.notify_one();

		//Processing
		if (D < this->temperature) {
			status = false;
		}
		else if (C > this->temperature) {
			status = true;
		}
		
		this->iSimulator.switchHeater(status);
		
		t1 = HRC::now();
		int elapsedTime = chrono::duration_cast<chrono::milliseconds>(t1 - t0).count();
		this_thread::sleep_for(chrono::milliseconds(this->tempFreq - elapsedTime));
	}
}

