#pragma once

#include "task.h"
#include "ISimulator.h"
#include "OperatorConsole.h"

#include <thread>

class PressureController : public Task
{
public:
	PressureController(ISimulator& simulator, OperatorConsole &opConsole);
	~PressureController();

	void start();

	void setPressure(double val);
	double getPressure();

	using HRC = std::chrono::high_resolution_clock;
	int pressFreq = 100;
private:

	ISimulator &iSimulator;
	OperatorConsole &opConsole;

	const double A = 5;
	const double B = 2;
	double pressure;

	thread *task;
	void pressThreadFunction();

};

