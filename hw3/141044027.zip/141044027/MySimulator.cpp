#include "MySimulator.h"
#include <thread>
#include <random>

using namespace std;
using namespace std::chrono;
using namespace this_thread;

MySimulator::MySimulator()
{
}


MySimulator::~MySimulator()
{	
}

void MySimulator::triggerADCPressure()
{
	//sleep_for(milliseconds(333));
}

void MySimulator::triggerADCTemperature()
{
	//sleep_for(milliseconds(333));
}

double MySimulator::readADCPressure()
{
	sleep_for(milliseconds(100));
	return pressure;
}

double MySimulator::readADCTemperature()
{
	sleep_for(milliseconds(100));
	return temperature;
}

void MySimulator::writeDACPump(const double value)
{
	std::default_random_engine randEng;
	std::uniform_real_distribution<double> randDist(-0.2, 0.2);
	this->pressure += value / 10.0 + randDist(randEng);
}

void MySimulator::switchHeater(bool isOn)
{
	std::default_random_engine randEng;
	std::uniform_real_distribution<double> randDist(0,2);

	if (isOn)
		this->temperature += randDist(randEng);
	else
		this->temperature -= randDist(randEng);
}
