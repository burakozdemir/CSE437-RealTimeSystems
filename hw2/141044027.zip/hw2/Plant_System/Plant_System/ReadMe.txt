========================================================================
    CONSOLE APPLICATION : Plant_System HW2 (Burak �zdemir 141044027)
========================================================================

1.Test i�in kendi Simulator s�n�f�n�z� �Simulator aray�z�nden implement edin.
2.PressureConroller frekans� 10 Hz, TemperatureController frekans� 3 Hz ,
OperatorConsole frekans� 2 Hz
3.Task'lar initialize edildikten sonra start() metodu ile ba�lat�l�r .
4.Pressure ve Temperature min max de�erleri header dosyalar�ndan manuel olarak
de�i�tirilebilir.

/////////////////////////////////////////////////////////////////////////////
Notes :
	-Test durumunda readADC fonksiyonunda random de�erler �rettirip max ve min 
aral�klar�nda gidip gelmesi sa�land� . 
	-Pressure initialize de�erinden ba�lay�p s�rekli '1' civarlar�nda gidip geldi
	-Temperature de�eri ise max ve min aral�klar�n d�zenli �ekilde artan ve azalan
de�erler g�sterdi .

/////////////////////////////////////////////////////////////////////////////
